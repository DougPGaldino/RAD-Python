import services.database as db;

def Incluir(cliente):
	
	db.cursor.execute("""
		INSERT INTO Proponente(proNome, proIdade, proOrgao) 
		VALUES (?, ? ,?)""", (proponente.nome, proponente.idade, proponente.profissao))
	db.con.commit()