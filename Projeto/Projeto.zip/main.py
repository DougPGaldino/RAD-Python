import streamlit as st
import Controllers.ProponenteController as ProponenteController
import models.proponente as proponente

st.title("Prospecção")

with st.form(key="include_proponente"):
    input_nome = st.text_input(label="Insira o nome do proponente")
    input_idade = st.number_input(label="Insira a idade do proponente", format="%d", step=1)
    input_orgao = st.selectbox("Selecione o órgão em que o proponente faz parte", options=["PMERJ", "Marinha do Brasil", "Aeronáutica", "UERJ", "Ministério Público"])
    input_button_submit = st.form_submit_button("Enviar")

if input_button_submit:
    proponente.nome = input_nome
    proponente.idade = input_idade
    proponente.orgao = input_orgao
    
    ProponenteController.Incluir(proponente)
    
    
    