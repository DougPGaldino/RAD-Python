import sqlite3



with sqlite3.connect('crud_python.db', check_same_thread=False) as con:
	cursor = con.cursor()
	cursor.execute(
		"""
		CREATE TABLE IF NOT EXISTS Proponente
		(
			id integer primary key autoincrement,
			proNome text not null,
			proIdade integer not null,
			proOrgao text
		)
		""") 