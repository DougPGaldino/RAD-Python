class Proponente:
    def __init__(self, nome, idade, orgao):
        self.nome = nome
        self.idade = idade
        self.orgao = orgao